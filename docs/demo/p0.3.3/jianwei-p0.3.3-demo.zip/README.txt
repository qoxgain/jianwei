解压后打开 index.html 查看实际数字报告，打开 应用界面.html 查看离线应用。
完整文件接入/原片回查/SOP复核需按 GitHub README 启动本地API。
包内不含原始视频、PDF或衍生截图，不代表独立学习验收。
